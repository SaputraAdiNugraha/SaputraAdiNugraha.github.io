<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

</div>
<!-- /.container -->

<!-- Footer -->
<footer>
  <p>ARTERI Arsip Elektronik Terintegrasi</p>
</footer>
<!-- /.Footer -->

<!-- jQuery -->
<script src="<?php echo base_url('/public/js/jquery-2.2.2.min.js')?>"></script>
<script src="<?php echo base_url('/public/js/bootstrap.min.js')?>"></script>
<script src="<?php echo base_url('/public/js/jquery-ui.min.js')?>"></script>
<script src="<?php echo base_url('/public/js/jquery.form.min.js')?>"></script>
<script src="<?php echo base_url('/public/js/chosen.jquery.min.js')?>"></script>
<script src="<?php echo base_url('/public/js/jquery.auto-complete.min.js')?>"></script>
<script src="<?php echo base_url('/public/js/custom.js')?>"></script>

</body>
</html>